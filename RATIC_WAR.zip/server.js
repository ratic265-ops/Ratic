const express = require("express");
const http = require("http");
const path = require("path");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
const PORT = process.env.PORT || 3000;
const players = new Map();

app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_req, res) => res.json({ ok: true, game: "RATIC WAR", players: players.size }));

io.on("connection", socket => {
  const player = { id: socket.id, x: 0, z: 0, yaw: 0, className: "Asalto" };
  players.set(socket.id, player);
  socket.emit("players:init", [...players.values()].filter(p => p.id !== socket.id));
  socket.broadcast.emit("player:joined", player);

  socket.on("player:update", data => {
    if (!data || typeof data !== "object") return;
    const x = Number(data.x), z = Number(data.z), yaw = Number(data.yaw);
    if (![x, z, yaw].every(Number.isFinite)) return;
    player.x = Math.max(-500, Math.min(500, x));
    player.z = Math.max(-500, Math.min(500, z));
    player.yaw = Math.max(-12.57, Math.min(12.57, yaw));
    const allowed = ["Asalto", "Médico", "Explorador", "Ingeniero", "Francotirador"];
    player.className = allowed.includes(data.className) ? data.className : "Asalto";
    socket.broadcast.emit("player:update", player);
  });

  socket.on("disconnect", () => {
    players.delete(socket.id);
    socket.broadcast.emit("player:left", socket.id);
  });
});

server.listen(PORT, "0.0.0.0", () => console.log(`RATIC WAR server on port ${PORT}`));
